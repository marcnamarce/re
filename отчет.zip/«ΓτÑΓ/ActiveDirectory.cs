https://orycan.ru/blog/post/class_ad_c
/// <summary>
        /// Проверка на вхождение пользователя в группу
        /// </summary>
        /// <param name="sUserName">Имя пользователя</param>
        /// <param name="sGroupName">Группа</param>
        /// <returns>Возвращает true, если пользователь входит в группу</returns>
        public static bool IsUserGroupMember(string sUserName, string sGroupName)
        {
            bool bResult = false;

            using (UserPrincipal oUserPrincipal = GetUser(sUserName))
            using (GroupPrincipal oGroupPrincipal = GetGroup(sGroupName))
            {
                if (oUserPrincipal != null && oGroupPrincipal != null)
                {
                    bResult = oGroupPrincipal.Members.Contains(oUserPrincipal);
                }
            }

            return bResult;
        } /// <summary>
        /// Возвращает пользователей находящихся в группе (более 1500 членов)
        /// </summary>
        /// <param name="sGroupName">Имя группы</param>
        /// <returns>Возвращает List со всеми пользователями группы</returns>
        public static List<string> ListMembersGroup1500(string sGroupName)
        {
            List<string> myItems = new List<string>();
            SearchResult group = LDAPFindOne("", sGroupName, LdapFilter.Groups);
            string gpDN = group.Properties["distinguishedName"][0].ToString();

            using (DirectoryEntry DE = new DirectoryEntry(gpDN))
            {
                IADsMembers groupMembers = (IADsMembers)DE.Invoke("members", null);
                
                foreach (object groupMember in groupMembers)
                {
                    IADs user = (IADs)groupMember;

                    myItems.Add(user.Name);
                   
                }
            }

            return myItems;
        }/// <summary>
        /// Возвращает список групп, в которых состоит пользователь
        /// </summary>
        /// <param name="sUserName">Имя пользователя</param>
        /// <returns>Возвращает List со всеми группами пользователя</returns>
        /*public static List<string> GetUserGroups(string sUserName)
        {
            List<string> myItems = new List<string>();
            UserPrincipal oUserPrincipal = GetUser(sUserName);
            if (oUserPrincipal != null)
            {
                using (PrincipalSearchResult<Principal> oPrincipalSearchResult = oUserPrincipal.GetGroups())
                {
                    foreach (Principal oResult in oPrincipalSearchResult)
                    {
                        myItems.Add(oResult.Name);
                    }
                }
            
            }  else return null;

            return myItems;
        }*/